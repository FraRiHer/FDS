package tienda;

public class Perecedero extends Producto{
	
	private int diasCaducar; 
	
	public Perecedero(int codigo, String descripcion, int precio, int cantidad, int diasCaducar) {
		super(codigo, descripcion, precio, cantidad);
		this.diasCaducar = diasCaducar;
	}

	/**
	 * @return the diasCaducar
	 */
	public int getDiasCaducar() {
		return diasCaducar;
	}

	/**
	 * @param diasCaducar the diasCaducar to set
	 */
	public void setDiasCaducar(int diasCaducar) {
		this.diasCaducar = diasCaducar;
	}
	
	
	public int calcularPrecio(int cantidad) {
		if(diasCaducar == 1) {
			precio = precio * 1/4;
		}
		else if (diasCaducar == 2) {
			precio = precio * 1/3;
		}
		else if (diasCaducar == 3) {
			precio = precio * 1/2;
		}
		return precio*cantidad; 
	}

	@Override
	public String toString() {
		return "\n" + "Perecedero: " + "\t" + "\t" + codigo + "\t" + descripcion + "\t" + "\t" + precio + "\t" + cantidad 
				+ "\t" + "\t" + diasCaducar + "\n" ;
	}
	
}
