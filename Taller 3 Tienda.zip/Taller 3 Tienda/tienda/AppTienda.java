package tienda;

import java.util.Scanner;
import java.util.ArrayList;

public class AppTienda {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		Perecedero prod1 = new Perecedero(1001, "QUESO", 5000, 100, 1);
		Perecedero prod2 = new Perecedero(1002, "CARNE", 10000, 50, 2);
		Perecedero prod3 = new Perecedero(1003, "NARANJAS", 2000, 500, 3);
		NoPerecedero pro1 = new NoPerecedero(101, "ATUN", 7000, 300, "Enlatado");
		NoPerecedero pro2 = new NoPerecedero(102, "CARNE SECA", 9000, 50, "Empacado Al Vacio");
		NoPerecedero pro3 = new NoPerecedero(103, "DURAZNOS", 6500, 100, "Enlatado");

		ArrayList<NoPerecedero> listaNoPerecederos = new ArrayList<NoPerecedero>();
		ArrayList<Perecedero> listaPerecederos = new ArrayList<Perecedero>();
		Tienda tienda = new Tienda(listaPerecederos, listaNoPerecederos);
		tienda.crearNoPerecedero(pro1);
		tienda.crearNoPerecedero(pro2);
		tienda.crearNoPerecedero(pro3);
		tienda.crearPerecedero(prod1);
		tienda.crearPerecedero(prod2);
		tienda.crearPerecedero(prod3);
		
		int variable = 0; 
		boolean terminarPrograma = true;
		
		do{
			
			System.out.println("~*MENU APP TIENDA*~"
					+ "\n1. Ver Productos."
					+ "\n2. Comprar Productos."
					+ "\n3. Terminar programa.");
			
			variable = input.nextInt();
			
			switch(variable){
			case 1:
				System.out.println("Los productos disponibles son:"
						+ "\n" + "Tipo de producto" + "\t" + "Codigo" + "\t" + "Producto" + "\t" + "Precio" + "\t" + "Cantidad" 
						+ "\t" + "Dias a caducar" );
				tienda.mostrarPerecdero();
				System.out.println("\n" + "Tipo de producto" + "\t" + "Codigo" + "\t" + "Producto" + "\t" + "Precio" + "\t" + "Cantidad" 
						+ "\t" + "Tipo de empaque" );
				tienda.mostrarNoPerecederos();

				break;
				
			case 2:
				boolean masProd= false; 
				int codProd;
				int cantProd;
				int bandera; 
				int factura = 0;
				
					do{

						System.out.println("Ingrese el codigo del producto que desea comprar ->");
						codProd = input.nextInt();
						System.out.println("Ingrese la cantidad del producto que desea comprar: ");
						cantProd = input.nextInt();
						
						System.out.println("Codigo" + "\tProducto" + "Valor" + "\tUnidades Compradas");
						tienda.vender(codProd, cantProd);
						
//						factura = tienda.encontrarProductoNoPerecedero(codProd, cantProd);
						
						factura = tienda.encontrarProductoPerecedero(codProd, cantProd);
						
						System.out.println("La factura de compra hasta el momento es: "+ factura);
												
						do {
							System.out.println("Desea comprar m�s productos? "
									+ "\n1-> Si"
									+ "\n2 -> No");
							bandera = input.nextInt();
						
							if(bandera == 1) {
								masProd = true; 
							}
							else if(bandera == 2) {
								System.out.println("La factura de compra es: " + factura);
								masProd = false;
							}
							else {
								System.out.println("Opcion Invalida");
							}

						}while(bandera !=1 && bandera != 2);
						
					}while(masProd == true);
					break; 
				
			case 3:
				System.out.println("El programa va a finalizar");
				System.out.println("Gracias, Vuelva pronto!! ");
				terminarPrograma = false;
				break;
			
			default: 
				System.out.println("�Opcion Invalida!");		
				break;
			}
						
		}while(terminarPrograma == true);
		
	}

}
