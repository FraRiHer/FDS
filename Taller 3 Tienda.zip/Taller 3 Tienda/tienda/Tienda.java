package tienda;

import java.util.ArrayList;

public class Tienda {
	private ArrayList<Perecedero> listaPerecederos;
	private ArrayList<NoPerecedero> listaNoPerecederos;
	/**
	 * @param listaPerecederos
	 * @param listaNoPerecederos
	 */
	public Tienda(ArrayList<Perecedero> listaPerecederos, ArrayList<NoPerecedero> listaNoPerecederos) {
		super();
		this.listaPerecederos = listaPerecederos;
		this.listaNoPerecederos = listaNoPerecederos;
	}
	
	public boolean crearPerecedero(Perecedero perecedero) {
		return listaPerecederos.add(perecedero);
	}
	
	public boolean crearNoPerecedero (NoPerecedero noPerecedero) {
		return listaNoPerecederos.add(noPerecedero);
	}
	
	public void mostrarPerecdero() {
		System.out.println(listaPerecederos.toString());
		System.out.println("\t");
	}
	
	public void mostrarNoPerecederos() {
		System.out.println(listaNoPerecederos.toString());
		System.out.println("\t");
	}
	
	public int encontrarProductoNoPerecedero(int codigo, int cantidad) {
		int auxiliar = 0;
		for (NoPerecedero noPerecedero : listaNoPerecederos) {
			if(noPerecedero.getCodigo()== codigo) {
				auxiliar=noPerecedero.calcularPrecioNoPerecedero(cantidad);
			}
			else {
				auxiliar = 0;
			}
		}
		return auxiliar;
	}
	
	
	public int encontrarProductoPerecedero(int codigo, int cantidad) {
		int auxiliar = 0;
		for (Perecedero perecedero : listaPerecederos) {
			if(perecedero.getCodigo()== codigo) {
				auxiliar= perecedero.calcularPrecio(cantidad);
			}
			else {
				auxiliar = 0;
			}
		}
		return auxiliar;
	}
	
	public void vender(int codigo, int cantidad) {
		int auxiliar=0;
		for (NoPerecedero noPerecedero : listaNoPerecederos) {
			if(noPerecedero.getCodigo()== codigo) {
				auxiliar=noPerecedero.calcularPrecioNoPerecedero(cantidad);
				System.out.println(noPerecedero.codigo + "\t" + noPerecedero.descripcion + "\t" + auxiliar + "\t" + cantidad);
				noPerecedero.setCantidad(noPerecedero.getCantidad()- cantidad);
			}
		}
		for (Perecedero perecedero : listaPerecederos) {
			if(perecedero.getCodigo()== codigo) {
				auxiliar= perecedero.calcularPrecio(cantidad);
				System.out.println(perecedero.codigo + "\t" + perecedero.descripcion + "\t" + auxiliar + "\t" + cantidad);
				perecedero.setCantidad(perecedero.getCantidad()- cantidad);
			}
		}
		
	}
}
