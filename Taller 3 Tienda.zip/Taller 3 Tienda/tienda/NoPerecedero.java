package tienda;

public class NoPerecedero extends Producto {
		
	private String tipoPerecedero; 
	
	public NoPerecedero(int codigo, String descripcion, int precio, int cantidad, String tipoPerecedero) {
		super(codigo, descripcion, precio, cantidad);
		this.tipoPerecedero=tipoPerecedero; 
	}
	
	/**
	 * @return the tipoPerecedero
	 */
	public String getTipoPerecedero() {
		return tipoPerecedero;
	}

	/**
	 * @param tipoPerecedero the tipoPerecedero to set
	 */
	public void setTipoPerecedero(String tipoPerecedero) {
		this.tipoPerecedero = tipoPerecedero;
	}

	public int calcularPrecioNoPerecedero (int cantidad) {
		precio*=cantidad;
		return precio;
	}

	@Override
	public String toString() {
		return "\n" + "Producto No Perecedero: " + codigo + "\t" + descripcion + "\t" + precio + "\t" + cantidad 
				+ "\t" + "\t" +  tipoPerecedero + "\n";
	}
	
	

	
}
